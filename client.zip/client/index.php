<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home</title>
  <link rel="stylesheet" href="css/index.css">

</head>

<body>

  <?php
  include ("header.php");
  ?>

  <!-- carousel -->
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
        aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
        aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
        aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active" >
        <img src="./images/bg1.jpg" class="d-block w-100 img-carousel" alt="..." />
        <div class="carousel-caption d-none d-md-block">
          <h5>First slide label</h5>
          <p>Some representative placeholder content for the first slide.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./images/bg2.jpg" class="d-block w-100 img-carousel" alt="..." />
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Some representative placeholder content for the second slide.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./images/bg3.jpg" class="d-block w-100 img-carousel" alt="..." />
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Some representative placeholder content for the third slide.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>


  <!-- ------------end------------- -->

  <section class="we-offer-area text-center bg-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="site-heading text-center">
            <h2>What we <span>Offer</span></h2>
            <h4>Lorem Ipsum is simply dummy text</h4>
          </div>
        </div>
      </div>
      <div class="row our-offer-items less-carousel">
        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-pen-fancy"></i>
            <h4>Project creation</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->

        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-dharmachakra"></i>
            <h4>Software Development</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->

        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-tasks"></i>
            <h4>Porject Management</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->

        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-tachometer-alt"></i>
            <h4>Porject Impliment</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->

        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-recycle"></i>
            <h4>Software Update</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->

        <!-- Single Item -->
        <div class="col-md-4 col-sm-6 equal-height">
          <div class="item">
            <i class="fas fa-headset"></i>
            <h4>24/7 Support</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <!-- End Single Item -->
      </div>
    </div>
  </section>

  <div class="contianer p-5">
    <div class="row">
      <div class="col-sm-4 p-3">
        <div class="card">
          <h3><span id="Partners">0</span>+</h3>
          <h3>Partners</h3>
        </div>
      </div>
      <div class="col-sm-4 p-3">
        <div class="card">
          <h3><span id="Projects">0</span>+</h3>
          <h3>Projects</h3>
        </div>
      </div>
      <div class="col-sm-4 p-3">
        <div class="card">
          <h3><span id="Clients">0</span>+</h3>
          <h3>Happy Clients</h3>
        </div>
      </div>
    </div>
  </div>

  <div class="container bg-danger">
    <div class="row p-5">
      <div class="col-sm-12 text-center">
        <h1 class="text-white text-center">Read Our Blogs</h1>
        <p class="text-white text-center">
          Find out about industry insights, learn from our experienced
          consultants or hear about some brilliant success stories from our
          temporary workers.
        </p>
        <a href="" class="btn btn-large btn-warning">Read More</a>
      </div>
    </div>
  </div>




  <div class="contianer p-5">
    <div class="row">

      <div class="col-sm-12">
        <h5 class="text-center bg-dark text-white">Testmonials</h5>

        <div class="slideshow1-container1">
          <div class="mySlides1 p-5">
            <q>I love you the more in that I believe you had liked me for my
              own sake and for nothing else</q>
            <p class="author1">- John Keats</p>
          </div>

          <div class="mySlides1 p-5">
            <q>But man is not made for defeat. A man can be destroyed but not
              defeated.</q>
            <p class="author1">- Ernest Hemingway</p>
          </div>

          <div class="mySlides1 p-5">
            <q>I have not failed. I've just found 10,000 ways that won't
              work.</q>
            <p class="author1">- Thomas A. Edison</p>
          </div>

          <a class="prev1" onclick="plusSlides(-1)">&#10094;</a>
          <a class="next1" onclick="plusSlides(1)">&#10095;</a>
        </div>

        <div class="dot1-container1 p-3">
          <span class="dot1" onclick="currentSlide(1)"></span>
          <span class="dot1" onclick="currentSlide(2)"></span>
          <span class="dot1" onclick="currentSlide(3)"></span>
        </div>
      </div>
    </div>
  </div>

  <?php
  include ("footer.php");
  ?>
  <script src="js/index.js"></script>
</body>
</html>
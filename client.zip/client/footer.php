   <!-- footer -->

   <footer class="bg-dark text-white">
      <div class="container footer">
        <div class="row p-5">
          <div class="col-md-3">
            <h5>Our Brand</h5>
            <img src="brand-logo.png" alt="Brand Logo" class="img-fluid" />
            <p>Description of your brand goes here.</p>
          </div>
          <div class="col-md-3">
            <h5>Quick Links</h5>
            <ul class="list-unstyled">
              <li><a href="#">Home</a></li>
              <li><a href="#">About</a></li>
              <li><a href="#">Services</a></li>
              <li><a href="#">News & Events</a></li>
              <li><a href="#">Contact</a></li>
            </ul>
          </div>
          <div class="col-md-3">
            <h5>Follow Us</h5>
            <ul class="list-unstyled">
              <li>
                <a href="#"><i class="bi bi-facebook"></i> Facebook</a>
              </li>
              <li>
                <a href="#"><i class="bi bi-twitter"></i> Twitter</a>
              </li>
              <li>
                <a href="#"><i class="bi bi-instagram"></i> Instagram</a>
              </li>
              <li>
                <a href="#"><i class="bi bi-linkedin"></i> LinkedIn</a>
              </li>
            </ul>
          </div>
          <div class="col-md-3">
            <h5>Contact Us</h5>
            <form>
              <div class="mb-3">
                <input type="text" class="form-control" placeholder="Name" />
              </div>
              <div class="mb-3">
                <input type="email" class="form-control" placeholder="Email" />
              </div>
              <div class="mb-3">
                <textarea class="form-control" placeholder="Message"></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
          </div>
        </div>

        <hr />
        <div class="row">
          <div class="col-md-12 text-center">
            <p>&copy; 2024 Your Company. All rights reserved.</p>
            <p>Website designed by Your Name</p>
          </div>
        </div>
      </div>
    </footer>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Contact Us</title>
<link rel="stylesheet" href="css/contact.css">

</head>
<body>
<?php

include("header.php");
?>





<section class="contact" id="contact">
    <div class="container">
        <div class="heading text-center">
            <h2>Contact
                <span> Us </span></h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                <br>incididunt ut labore et dolore magna aliqua.</p>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="title">
                    <h3>Contact detail</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor </p>
                </div>
                <div class="content">
                    <!-- Info-1 -->
                    <div class="info">
                        <i class="fas fa-mobile-alt"></i>
                        <h4 class="d-inline-block">PHONE :
                            <br>
                            <span>+12457836913 , +12457836913</span></h4>
                    </div>
                    <!-- Info-2 -->
                    <div class="info">
                        <i class="far fa-envelope"></i>
                        <h4 class="d-inline-block">EMAIL :
                            <br>
                            <span>example@info.com</span></h4>
                    </div>
                    <!-- Info-3 -->
                    <div class="info">
                        <i class="fas fa-map-marker-alt"></i>
                        <h4 class="d-inline-block">ADDRESS :<br>
                            <span>6743 last street , Abcd, Xyz</span></h4>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <form>
                    <div class="row">
                        <div class="col-sm-6">
                            <input type="text" class="form-control" placeholder="Name">
                        </div>
                        <div class="col-sm-6">
                            <input type="email" class="form-control" placeholder="Email">
                        </div>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" placeholder="Subject">
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" rows="5" id="comment" placeholder="Message"></textarea>
                    </div>
                    <button class="btn btn-block" type="submit">Send Now!</button>
                </form>
            </div>
        </div>
    </div>
</section>



<div class="container">
    <div class="row">
        <div class="col-sm-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3823.6728225557276!2d81.7424682!3d16.5929684!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a37c4e4e621d073%3A0x5b769d2c8b446f31!2sCheruvu!5e0!3m2!1sen!2sin!4v1711710982027!5m2!1sen!2sin" style="width:100%;height:300px"   allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
    
    
    </body>
    </html>

<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/blogs.css">
  <title>Home | Blogs</title>
</head>

<body>
  <?php
  include ("header.php");
  ?>




  <div class="container">
    <div class="row">
      <div class="col-sm-12">


        <div class="row1">
          <div class="leftcolumn1">
            <div class="card1">
              <h2>TITLE HEADING</h2>
              <h5>Title description, Dec 7, 2017</h5>
              <div class="fakeimg1" style="height:200px;">Image</div>
              <p>Some text..</p>
            </div>
            <div class="card1">
              <h2>TITLE HEADING</h2>
              <h5>Title description, Sep 2, 2017</h5>
              <div class="fakeimg1" style="height:200px;">Image</div>
              <p>Some text..</p>
            </div>
          </div>
          <div class="rightcolumn1">
            <div class="card1">
              <h2>About Me</h2>
              <div class="fakeimg1" style="height:100px;">Image</div>
              <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
            </div>
            <div class="card1">
              <h3>Popular Post</h3>
              <div class="fakeimg1">Image</div><br>
              <div class="fakeimg1">Image</div><br>
              <div class="fakeimg1">Image</div>
            </div>
            <div class="card1">
              <h3>Follow Me</h3>
              <p>Some text..</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <?php
  include ("footer.php");
  ?>
</body>

</html>